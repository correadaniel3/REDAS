$(document).ready(function(){

  $(".pit-thumbnail-descripcion h3").each(function() {
    var titleLength = $(this).text().length;
    console.log(titleLength);
    if (titleLength <= 20) {
      console.log("Menor que 20");
      $(this).css("margin-top","7%");
    }else if (titleLength > 20 && titleLength < 35) {
      console.log("Entre 20 y 35");
      $(this).css("margin-top","3%");
    }else if (titleLength >= 35) {
      console.log("Mayor que 35");
      $(this).css("margin-top","4%");
      $(this).css("font-size","12px");
      $(this).css("margin-left","6px");
      $(this).css("margin-right","6px");
    }
  });
  $(".dialog").dialog({
      dialogClass: "no-close",
      modal:true,
      autoOpen: false,
      width:Math.min(600, $(window).width() * 0.9),
      resizable: false,
      maxHeight:800
  });


  $("#bibliografia,#bibliografia-mobile").on('click touchstart', function(){
    $("#dialog-1").dialog("open");
    console.log("Entro en dialog-1");
  })
  $("#informacion,#informacion-mobile").on('click touchstart', function(){
    $("#dialog-2").dialog("open");
    console.log("Entro en dialog-3");
  })

  $("#creditos,#creditos-mobile").on('click touchstart', function(){
    $("#dialog-3").dialog("open");
    console.log("Entro en dialog-2");
  })

  $(".pit-hamburguer").click( function () {
    $(".pit-menu-mobile").toggleClass("show-menu");
  });

});
