$(document).ready(function(){
    $("#errores").hide();
    $("#text_boton2").hide();
    $("#text_pregunta2").hide();
    $("#text_pregunta3").hide();
    $("#text_pregunta4").hide();
    $("#text_pregunta6").hide();
    $("#text_pregunta7").hide();
    $("#text_pregunta8").hide();
    $(".respuestas").hide();
    $("#text_dopamina").hide();
    $("#text_prolactina").hide();
    $("#text_estrogenos").hide();
    $("#text_trh").hide();
    $("#text_hipofisario").hide();
    $("#text_galactorrea").hide();
    $("#text_osteoporosis").hide();
    $("#text_Hipogonadismo").hide();
    $("#text_hipofisario2").hide();
    $("#text_galactorrea2").hide();
    $("#text_osteoporosis2").hide();
    $("#text_Hipogonadismo2").hide();

    $("#boton1").addClass("boton_activo");
    $("#pregunta1").addClass("pregunta_activa");

    function habilitar(){
        $(".grid").children("li").each(function(){
            if(!($(this).hasClass("activo"))){
                $(this).hide();
            }
            else{
                $(this).fadeIn();
            }
        });
    }
    habilitar();

    $( ".dialog" ).dialog({
        dialogClass: "no-close",
        modal:true,
        autoOpen: false,
        width:800,
        maxHeight:900
    });
    $( ".dialog_causas" ).dialog({
        dialogClass: "no-close",
        modal:true,
        autoOpen: false,
        width:1300,
        maxHeight:1350
    });
    $( ".dialog_dopamina" ).dialog({
        dialogClass: "no-close",
        modal:true,
        autoOpen: false,
        width:1000,
        maxHeight:1350
    });

    $("#bibliografia").click(function(){
        $("#dialog1").dialog("open");
    });
    $("#creditos").click(function(){
        $("#dialog2").dialog("open");
    });
    $(".produccion_secrecion").click(function(){      
        $("#dialog3").dialog("open");
    });
    $(".papel_adaptacion").click(function(){      
        $("#dialog4").dialog("open");
    });
    $(".causas").click(function(){      
        $("#dialog5").dialog("open");
    });
    $(".epidemiologia").click(function(){      
        $("#dialog6").dialog("open");
    });
    
    $("#boton1").click(function(){      
        $("#text_boton2").hide();
        $("#text_boton1").fadeIn();
        $("#boton1").addClass("boton_activo");
        $("#boton2").removeClass("boton_activo");
    });
    $("#boton2").click(function(){      
        $("#text_boton1").hide();
        $("#text_boton2").fadeIn();
        $("#boton2").addClass("boton_activo");
        $("#boton1").removeClass("boton_activo");
    });

    $("#home").click(function(){
       window.open('hiperprolactinemia.html',"_self");
    });

    $("#bibliografia").on("mouseover", function mouseOver(){
        $("#bibliografia").attr("src","imagenes/icono_01_hover.png");
    });
    $("#bibliografia").on("mouseout", function mouseOut(){
        $("#bibliografia").attr("src","imagenes/icono_01.png");
    });

    $("#creditos").on("mouseover", function mouseOver(){
        $("#creditos").attr("src","imagenes/icono_02_hover.png");
    });
    $("#creditos").on("mouseout", function mouseOut(){
        $("#creditos").attr("src","imagenes/icono_02.png");
    });

    $("#home").on("mouseover", function mouseOver(){
        $("#home").attr("src","imagenes/icono_03_hover.png");
    });
    $("#home").on("mouseout", function mouseOut(){
        $("#home").attr("src","imagenes/icono_03.png");
    });

    $(".pit_vertical_tabs ul li").click(function(){
        $(".respuestas").hide();
    });
    $(".pit_tabs ul li").click(function(){
        $(".respuestas").hide();
    });
    $(".ver_respuesta1").click(function(){
        $(".respuestas").fadeIn();
        $("#respuesta_1").fadeIn();
        $("#r_falso").css("color","red");
        $("#r_falso").css("font-weight","bold");
    });
    $(".ver_respuesta2").click(function(){
        $(".respuestas").fadeIn();
        $("#respuesta_2").fadeIn();
        $("#r_organica").css("color","red");
        $("#r_organica").css("font-weight","bold");
    });
    $(".ver_respuesta3").click(function(){
        $("#r_agonistas").css("color","red");
        $("#r_agonistas").css("font-weight","bold");
    });
    $(".ver_respuesta4").click(function(){
        $("#r_bromocriptina").css("color","red");
        $("#r_bromocriptina").css("font-weight","bold");
    });
    $(".ver_respuesta5").click(function(){
        $("#r_gancho").css("color","red");
        $("#r_gancho").css("font-weight","bold");
        $(".respuestas").fadeIn();
        $("#respuesta_1").fadeIn();
    });
    $(".ver_respuesta6").click(function(){
        $("#r_organica2").css("color","red");
        $("#r_organica2").css("font-weight","bold");
        $(".respuestas").fadeIn();
        $("#respuesta_1").fadeIn();
    });
    $(".ver_respuesta7").click(function(){
        $("#r_verdadero2").css("color","red");
        $("#r_verdadero2").css("font-weight","bold");
    });
    $(".ver_respuesta8").click(function(){
        $("#r_agonistas2").css("color","red");
        $("#r_agonistas2").css("font-weight","bold");
    });
    $(".ver_respuesta9").click(function(){
        $("#r_cabergolina").css("color","red");
        $("#r_cabergolina").css("font-weight","bold");
        $(".respuestas").fadeIn();
        $("#respuesta_1").fadeIn();
    });

    $(".info_dopamina").on("mouseover", function mouseOver(){
        $("#text_dopamina").fadeIn("slow");
    });
    $(".info_dopamina").on("mouseout", function mouseOut(){
        $("#text_dopamina").hide("slow");
    });
    $(".info_prolactina").on("mouseover", function mouseOver(){
        $("#text_prolactina").fadeIn("slow");
    });
    $(".info_prolactina").on("mouseout", function mouseOut(){
        $("#text_prolactina").hide("slow");
    });
    $(".info_estrogenos").on("mouseover", function mouseOver(){
        $("#text_estrogenos").fadeIn("slow");
    });
    $(".info_estrogenos").on("mouseout", function mouseOut(){
        $("#text_estrogenos").hide("slow");
    });
    $(".info_trh").on("mouseover", function mouseOver(){
        $("#text_trh").fadeIn("slow");
    });
    $(".info_trh").on("mouseout", function mouseOut(){
        $("#text_trh").hide("slow");
    });

    $("#img_produccion_secrecion").on("mouseover", function mouseOver(){
        $("#img_produccion_secrecion").attr("src","imagenes/seccion1/001_boton_mouseOver.png");
    });
    $("#img_produccion_secrecion").on("mouseout", function mouseOut(){
        $("#img_produccion_secrecion").attr("src","imagenes/seccion1/001_boton.png");
    });
    $("#img_papel_adaptacion").on("mouseover", function mouseOver(){
        $("#img_papel_adaptacion").attr("src","imagenes/seccion1/002_boton_mouseOver.png");
    });
    $("#img_papel_adaptacion").on("mouseout", function mouseOut(){
        $("#img_papel_adaptacion").attr("src","imagenes/seccion1/002_boton.png");
    });
    $("#img_causasl").on("mouseover", function mouseOver(){
        $("#img_causasl").attr("src","imagenes/seccion1/003_boton_mouseOver.png");
    });
    $("#img_causasl").on("mouseout", function mouseOut(){
        $("#img_causasl").attr("src","imagenes/seccion1/003_boton.png");
    });
    $("#img_epidemiologia").on("mouseover", function mouseOver(){
        $("#img_epidemiologia").attr("src","imagenes/seccion1/004_boton_mouseOver.png");
    });
    $("#img_epidemiologia").on("mouseout", function mouseOut(){
        $("#img_epidemiologia").attr("src","imagenes/seccion1/004_boton.png");
    });

    $(".info_hipofisario").on("mouseover", function mouseOver(){
        $("#text_hipofisario").fadeIn("slow");
    });
    $(".info_hipofisario").on("mouseout", function mouseOut(){
        $("#text_hipofisario").hide("slow");
    });
    $(".info_galactorrea").on("mouseover", function mouseOver(){
        $("#text_galactorrea").fadeIn("slow");
    });
    $(".info_galactorrea").on("mouseout", function mouseOut(){
        $("#text_galactorrea").hide("slow");
    });
    $(".info_osteoporosis").on("mouseover", function mouseOver(){
        $("#text_osteoporosis").fadeIn("slow");
    });
    $(".info_osteoporosis").on("mouseout", function mouseOut(){
        $("#text_osteoporosis").hide("slow");
    });
    $(".info_Hipogonadismo").on("mouseover", function mouseOver(){
        $("#text_Hipogonadismo").fadeIn("slow");
    });
    $(".info_Hipogonadismo").on("mouseout", function mouseOut(){
        $("#text_Hipogonadismo").hide("slow");
    });
    $(".info_hipofisario2").on("mouseover", function mouseOver(){
        $("#text_hipofisario2").fadeIn("slow");
    });
    $(".info_hipofisario2").on("mouseout", function mouseOut(){
        $("#text_hipofisario2").hide("slow");
    });
    $(".info_galactorrea2").on("mouseover", function mouseOver(){
        $("#text_galactorrea2").fadeIn("slow");
    });
    $(".info_galactorrea2").on("mouseout", function mouseOut(){
        $("#text_galactorrea2").hide("slow");
    });
    $(".info_osteoporosis2").on("mouseover", function mouseOver(){
        $("#text_osteoporosis2").fadeIn("slow");
    });
    $(".info_osteoporosis2").on("mouseout", function mouseOut(){
        $("#text_osteoporosis2").hide("slow");
    });
    $(".info_Hipogonadismo2").on("mouseover", function mouseOver(){
        $("#text_Hipogonadismo2").fadeIn("slow");
    });
    $(".info_Hipogonadismo2").on("mouseout", function mouseOut(){
        $("#text_Hipogonadismo2").hide("slow");
    });

    $(".pausar").click(function(){
        $("video").each(function () { this.pause() });
    });
});